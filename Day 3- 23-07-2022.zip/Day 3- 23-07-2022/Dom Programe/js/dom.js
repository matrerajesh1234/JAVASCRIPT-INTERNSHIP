function ExternalAlert(){
    alert("This is ExternalAlert");
}

function ExternalConfirm(){
    alert("Are You sure");
}

function ExternalPrompt(){
    let x = prompt("Enter the Name")
    alert(x);
}